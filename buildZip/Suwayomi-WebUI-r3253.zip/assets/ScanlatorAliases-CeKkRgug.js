import{r as e}from"./chunk-CilyBKbf.js";import{$t as t,Ai as n,At as r,Ct as i,Ft as a,Gi as o,Hi as s,P as c,Ui as l,Vi as u,Wi as d,bs as f,cs as p,fo as m,ga as h,ha as g,ji as _,la as v,ma as y,pa as b,so as x,xt as S,ys as C}from"./index-CcV0bPG8.js";import{t as w}from"./ListSubheader-Dk-DIPPt.js";import{t as T}from"./useAppTitle-BM2jerQ9.js";import{t as E}from"./Delete-BoAfprgw.js";import{t as D}from"./Edit-CzpdJObl.js";var O=f(),k=e(C(),1),A=p`
    fragment SCANLATOR_ALIAS_FIELDS on ScanlatorAliasType {
        id
        scanlator
        displayName
        createdAt
        updatedAt
    }
`,j=p`
    ${A}
    mutation CREATE_SCANLATOR_ALIAS($input: CreateScanlatorAliasInput!) {
        createScanlatorAlias(input: $input) {
            scanlatorAlias {
                ...SCANLATOR_ALIAS_FIELDS
            }
        }
    }
`,M=p`
    ${A}
    mutation UPDATE_SCANLATOR_ALIAS($input: UpdateScanlatorAliasInput!) {
        updateScanlatorAlias(input: $input) {
            scanlatorAlias {
                ...SCANLATOR_ALIAS_FIELDS
            }
        }
    }
`,ee=p`
    mutation DELETE_SCANLATOR_ALIAS($input: DeleteScanlatorAliasInput!) {
        deleteScanlatorAlias(input: $input) {
            deleted
        }
    }
`,N=p`
    ${A}
    query GET_SCANLATOR_ALIASES {
        scanlatorAliases {
            totalCount
            nodes {
                ...SCANLATOR_ALIAS_FIELDS
            }
        }
    }
`,P=p`
    query GET_DISTINCT_SCANLATORS($inLibraryOnly: Boolean) {
        distinctScanlators(inLibraryOnly: $inLibraryOnly) {
            scanlator
            chapterCount
            currentAlias
        }
    }
`;function F(){let{i18n:e,_:f}=x();T(e._({id:`zFuG9J`}));let p=t.graphQLClient.client,C=n(P,{client:p,variables:{inLibraryOnly:!1}}),A=n(N,{client:p}),F={client:p,refetchQueries:[P,N]},[I,L]=_(j,F),[R,z]=_(M,F),[B,V]=_(ee,F),[H,U]=(0,k.useState)(null),[W,G]=(0,k.useState)(``),K=(0,k.useMemo)(()=>{let e=new Map;return A.data?.scanlatorAliases.nodes.forEach(t=>{e.set(t.scanlator,{id:t.id,displayName:t.displayName})}),e},[A.data]),q=(0,k.useMemo)(()=>{let e=new Set(C.data?.distinctScanlators.map(e=>e.scanlator));return(A.data?.scanlatorAliases.nodes??[]).filter(t=>!e.has(t.scanlator))},[A.data,C.data]),J=e=>{U(e),G(e.displayName)},Y=()=>{U(null),G(``)},X=async()=>{if(!H)return;let e=W.trim();e&&(H.aliasId==null?await I({variables:{input:{scanlator:H.scanlator,displayName:e}}}):await R({variables:{input:{id:H.aliasId,patch:{displayName:e}}}}),Y())},Z=async e=>{await B({variables:{input:{id:e}}})},Q=C.loading||A.loading,$=L.error??z.error??V.error;return(0,O.jsxs)(m,{sx:{p:2},children:[(0,O.jsx)(b,{variant:`body2`,color:`text.secondary`,sx:{mb:2},children:e._({id:`26Osr6`})}),$&&(0,O.jsx)(y,{severity:`error`,sx:{mb:2},children:$.message}),Q?(0,O.jsx)(m,{sx:{display:`flex`,justifyContent:`center`,p:4},children:(0,O.jsx)(h,{})}):(0,O.jsxs)(a,{sx:{pt:0},subheader:(0,O.jsx)(w,{disableSticky:!0,children:e._({id:`FOIBn8`})}),children:[(C.data?.distinctScanlators??[]).length===0&&(0,O.jsx)(S,{children:(0,O.jsx)(i,{primary:e._({id:`l2JaIU`}),secondary:e._({id:`YCdfoq`})})}),(C.data?.distinctScanlators??[]).map(t=>{let n=K.get(t.scanlator);return(0,O.jsx)(S,{secondaryAction:(0,O.jsxs)(u,{direction:`row`,spacing:.5,children:[(0,O.jsx)(r,{title:n?e._({id:`1yF_rE`}):e._({id:`THpQth`}),children:(0,O.jsx)(g,{edge:`end`,onClick:()=>J({scanlator:t.scanlator,aliasId:n?.id,displayName:n?.displayName??t.scanlator}),children:(0,O.jsx)(D,{})})}),n&&(0,O.jsx)(r,{title:e._({id:`CE5-01`}),children:(0,O.jsx)(g,{edge:`end`,onClick:()=>Z(n.id),children:(0,O.jsx)(E,{})})})]}),children:(0,O.jsx)(i,{primary:n?`${n.displayName} → ${t.scanlator}`:t.scanlator,secondary:e._({id:`A5vgLW`,values:{0:t.chapterCount}})})},t.scanlator)}),q.length>0&&(0,O.jsxs)(O.Fragment,{children:[(0,O.jsx)(w,{disableSticky:!0,children:e._({id:`fWvx3Q`})}),(0,O.jsx)(S,{children:(0,O.jsx)(i,{secondary:e._({id:`YlOWam`})})}),q.map(t=>(0,O.jsx)(S,{secondaryAction:(0,O.jsxs)(u,{direction:`row`,spacing:.5,children:[(0,O.jsx)(r,{title:e._({id:`1yF_rE`}),children:(0,O.jsx)(g,{edge:`end`,onClick:()=>J({scanlator:t.scanlator,aliasId:t.id,displayName:t.displayName}),children:(0,O.jsx)(D,{})})}),(0,O.jsx)(r,{title:e._({id:`CE5-01`}),children:(0,O.jsx)(g,{edge:`end`,onClick:()=>Z(t.id),children:(0,O.jsx)(E,{})})})]}),children:(0,O.jsx)(i,{primary:`${t.displayName} → ${t.scanlator}`})},t.id))]})]}),(0,O.jsxs)(o,{open:H!=null,onClose:Y,fullWidth:!0,maxWidth:`sm`,children:[(0,O.jsx)(s,{children:H?.aliasId==null?e._({id:`GRdzxf`}):e._({id:`mwk3Lz`})}),(0,O.jsxs)(l,{children:[(0,O.jsx)(b,{variant:`body2`,color:`text.secondary`,sx:{mb:2},children:e._({id:`XLtJxm`,values:{0:H?.scanlator??``}})}),(0,O.jsx)(c,{autoFocus:!0,fullWidth:!0,label:e._({id:`pfa8F0`}),value:W,onChange:e=>G(e.target.value),onKeyDown:e=>{e.key===`Enter`&&(e.preventDefault(),X())}})]}),(0,O.jsxs)(d,{children:[(0,O.jsx)(v,{onClick:Y,children:e._({id:`dEgA5A`})}),(0,O.jsx)(v,{variant:`contained`,onClick:X,disabled:!W.trim(),children:e._({id:`tfDRzk`})})]})]})]})}export{F as ScanlatorAliases};