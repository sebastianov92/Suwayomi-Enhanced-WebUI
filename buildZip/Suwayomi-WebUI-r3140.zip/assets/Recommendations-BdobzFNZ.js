import{D as e,Mi as t,Ss as n,Ui as r,ga as i,ha as a,lo as o,mo as s,tn as c,us as l,va as u}from"./index-DGbIOvdv.js";import{t as d}from"./useAppTitle-8nuHtiRv.js";import{t as f}from"./CardActionArea-BM5UWnrh.js";import{t as p}from"./Card-Dy9GdyS0.js";import{t as m}from"./CardContent-Cp0yJuE3.js";import{t as h}from"./Avatar-De9hBLkp.js";var g=n(),_=l`
    fragment RECOMMENDATION_FIELDS on RecommendationEntry {
        anilistId
        title
        coverUrl
        description
        genres
        averageScore
        rating
        anilistUrl
        sourceMangaId
        sourceMangaTitle
    }
`;l`
    ${_}
    query GET_MANGA_RECOMMENDATIONS($mangaId: Int!) {
        mangaRecommendations(mangaId: $mangaId) {
            ...RECOMMENDATION_FIELDS
        }
    }
`;var v=l`
    ${_}
    query GET_LIBRARY_RECOMMENDATIONS($perMangaLimit: Int, $totalLimit: Int) {
        libraryRecommendations(perMangaLimit: $perMangaLimit, totalLimit: $totalLimit) {
            ...RECOMMENDATION_FIELDS
        }
    }
`,y=e=>e?e.replace(/<[^>]+>/g,``).trim():``;function b(){let{i18n:n,_:l}=o();d(n._({id:`FXN0ro`}));let _=c.graphQLClient.client,{data:b,loading:x,error:S}=t(v,{client:_,variables:{perMangaLimit:5,totalLimit:60},fetchPolicy:`cache-and-network`}),C=b?.libraryRecommendations??[];return(0,g.jsxs)(s,{sx:{p:2,maxWidth:1100,mx:`auto`},children:[(0,g.jsx)(a,{variant:`body2`,color:`text.secondary`,sx:{mb:2},children:n._({id:`ZAQ1Uu`})}),x&&(0,g.jsx)(s,{sx:{display:`flex`,justifyContent:`center`,py:4},children:(0,g.jsx)(u,{})}),S&&(0,g.jsx)(i,{severity:`error`,sx:{mb:2},children:S.message}),!x&&!S&&C.length===0&&(0,g.jsx)(i,{severity:`info`,children:n._({id:`JFG_EH`})}),(0,g.jsx)(r,{spacing:1,children:C.map(t=>(0,g.jsx)(p,{children:(0,g.jsxs)(f,{component:`a`,href:t.anilistUrl??`https://anilist.co/manga/${t.anilistId}`,target:`_blank`,rel:`noopener`,sx:{display:`flex`,alignItems:`stretch`},children:[(0,g.jsx)(h,{variant:`rounded`,src:t.coverUrl??void 0,alt:t.title,sx:{width:80,height:120,m:1,flexShrink:0,bgcolor:`background.default`}}),(0,g.jsxs)(m,{sx:{flex:1,minWidth:0},children:[(0,g.jsxs)(r,{direction:`row`,spacing:1,sx:{alignItems:`baseline`,flexWrap:`wrap`},children:[(0,g.jsx)(a,{variant:`subtitle1`,sx:{flex:1,minWidth:0},noWrap:!0,children:t.title}),typeof t.averageScore==`number`&&(0,g.jsx)(e,{size:`small`,label:`★ ${t.averageScore}`}),typeof t.rating==`number`&&t.rating>0&&(0,g.jsx)(e,{size:`small`,variant:`outlined`,label:`+${t.rating}`})]}),t.sourceMangaTitle&&(0,g.jsx)(a,{variant:`caption`,color:`text.secondary`,children:n._({id:`7rY8Sk`,values:{0:t.sourceMangaTitle}})}),t.genres&&t.genres.length>0&&(0,g.jsx)(a,{variant:`body2`,color:`text.secondary`,sx:{mt:.5},noWrap:!0,children:t.genres.join(`, `)}),t.description&&(0,g.jsx)(a,{variant:`body2`,color:`text.secondary`,sx:{mt:.5,display:`-webkit-box`,WebkitLineClamp:3,WebkitBoxOrient:`vertical`,overflow:`hidden`},children:y(t.description)})]})]})},t.anilistId))})]})}export{b as Recommendations};