import{D as e,Lt as t,Mi as n,Ni as r,Ss as i,St as a,Ui as o,da as s,ga as c,ha as l,lo as u,mo as d,on as f,os as p,tn as m,us as h,va as g,wt as _}from"./index-DGbIOvdv.js";import{t as v}from"./useAppTitle-8nuHtiRv.js";var y=i(),b=h`
    query GET_LOCAL_SOURCE_ENTRIES {
        localSourceEntries {
            name
            type
            sizeBytes
            itemCount
            lastModified
        }
    }
`,x=h`
    mutation RESCAN_LOCAL_SOURCE($input: RescanLocalSourceInput!) {
        rescanLocalSource(input: $input) {
            imported
        }
    }
`,S=e=>{if(e<1024)return`${e} B`;let t=[`KB`,`MB`,`GB`,`TB`],n=e/1024,r=0;for(;n>=1024&&r<t.length-1;)n/=1024,r+=1;return`${n.toFixed(1)} ${t[r]}`};function C(){let{i18n:i,_:h}=u();v(i._({id:`LECJgZ`}));let C=m.graphQLClient.client,{data:w,loading:T,error:E,refetch:D}=n(b,{client:C,fetchPolicy:`cache-and-network`}),[O,k]=r(x,{client:C}),A=w?.localSourceEntries??[];return(0,y.jsxs)(d,{sx:{p:2},children:[(0,y.jsxs)(o,{direction:`row`,spacing:1,sx:{mb:2,alignItems:`center`},children:[(0,y.jsx)(l,{variant:`body2`,color:`text.secondary`,sx:{flex:1},children:i._({id:`1746P2`})}),(0,y.jsx)(s,{variant:`contained`,onClick:async()=>{try{let e=(await O({variables:{input:{}}})).data?.rescanLocalSource?.imported??0;f(i._({id:`L-RWYf`,values:{count:e}}),`success`),D().catch(()=>{})}catch(e){f(i._({id:`gVINQc`}),`error`,p(e))}},disabled:k.loading,children:i._({id:`Igjjz3`})})]}),E&&(0,y.jsx)(c,{severity:`error`,sx:{mb:2},children:E.message}),k.error&&(0,y.jsx)(c,{severity:`error`,sx:{mb:2},children:k.error.message}),T?(0,y.jsx)(d,{sx:{display:`flex`,justifyContent:`center`,p:4},children:(0,y.jsx)(g,{})}):A.length===0?(0,y.jsx)(c,{severity:`info`,children:i._({id:`MY0lRL`})}):(0,y.jsx)(t,{sx:{pt:0},children:A.map(t=>(0,y.jsx)(a,{secondaryAction:(0,y.jsxs)(o,{direction:`row`,spacing:.5,children:[(0,y.jsx)(e,{size:`small`,label:t.type}),(0,y.jsx)(e,{size:`small`,variant:`outlined`,label:S(Number(t.sizeBytes))})]}),children:(0,y.jsx)(_,{primary:t.name,secondary:t.type===`folder`?i._({id:`nO9aok`,values:{0:t.itemCount,1:new Date(Number(t.lastModified)).toLocaleString()}}):i._({id:`csbOd5`,values:{0:new Date(Number(t.lastModified)).toLocaleString()}})})},t.name))})]})}export{C as LocalSourceTools};