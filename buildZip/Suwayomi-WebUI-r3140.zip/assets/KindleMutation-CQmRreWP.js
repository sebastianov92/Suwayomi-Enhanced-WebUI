import{us as e}from"./index-DGbIOvdv.js";var t=e`
    mutation SEND_CHAPTER_TO_KINDLE($input: SendChapterToKindleInput!) {
        sendChapterToKindle(input: $input) {
            queueEntryId
            alreadyQueued
        }
    }
`,n=e`
    mutation CANCEL_KINDLE_QUEUE_ENTRY($input: CancelKindleQueueEntryInput!) {
        cancelKindleQueueEntry(input: $input) {
            cancelled
        }
    }
`,r=e`
    mutation RETRY_KINDLE_QUEUE_ENTRY($input: RetryKindleQueueEntryInput!) {
        retryKindleQueueEntry(input: $input) {
            retried
        }
    }
`,i=e`
    mutation SET_MANGA_KINDLE_CONFIG($input: SetMangaKindleConfigInput!) {
        setMangaKindleConfig(input: $input) {
            mangaId
            autoSend
            destination
        }
    }
`,a=e`
    mutation SET_SMTP_PASSWORD($input: SetSmtpPasswordInput!) {
        setSmtpPassword(input: $input) {
            saved
        }
    }
`,o=e`
    mutation SEND_TEST_EMAIL($input: SendTestEmailInput!) {
        sendTestEmail(input: $input) {
            sent
            message
        }
    }
`;export{i as a,o as i,r as n,a as o,t as r,n as t};