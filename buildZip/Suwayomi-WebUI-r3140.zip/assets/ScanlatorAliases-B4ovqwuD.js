import{r as e}from"./chunk-CilyBKbf.js";import{F as t,Gi as n,Ki as r,Lt as i,Mi as a,Ni as o,Ss as s,St as c,Ui as l,Wi as u,_a as d,da as f,ga as p,ha as m,kt as h,lo as g,mo as _,qi as v,tn as y,us as b,va as ee,wt as x,xs as S}from"./index-DGbIOvdv.js";import{t as C}from"./ListSubheader-BBGyS1PD.js";import{t as w}from"./useAppTitle-8nuHtiRv.js";import{t as T}from"./Delete-CttW37VI.js";import{t as E}from"./Edit-B5fwzNsu.js";var D=s(),O=e(S(),1),k=b`
    fragment SCANLATOR_ALIAS_FIELDS on ScanlatorAliasType {
        id
        scanlator
        displayName
        createdAt
        updatedAt
    }
`,A=b`
    ${k}
    mutation CREATE_SCANLATOR_ALIAS($input: CreateScanlatorAliasInput!) {
        createScanlatorAlias(input: $input) {
            scanlatorAlias {
                ...SCANLATOR_ALIAS_FIELDS
            }
        }
    }
`,j=b`
    ${k}
    mutation UPDATE_SCANLATOR_ALIAS($input: UpdateScanlatorAliasInput!) {
        updateScanlatorAlias(input: $input) {
            scanlatorAlias {
                ...SCANLATOR_ALIAS_FIELDS
            }
        }
    }
`,M=b`
    mutation DELETE_SCANLATOR_ALIAS($input: DeleteScanlatorAliasInput!) {
        deleteScanlatorAlias(input: $input) {
            deleted
        }
    }
`,N=b`
    ${k}
    query GET_SCANLATOR_ALIASES {
        scanlatorAliases {
            totalCount
            nodes {
                ...SCANLATOR_ALIAS_FIELDS
            }
        }
    }
`,P=b`
    query GET_DISTINCT_SCANLATORS($inLibraryOnly: Boolean) {
        distinctScanlators(inLibraryOnly: $inLibraryOnly) {
            scanlator
            chapterCount
            currentAlias
        }
    }
`;function F(){let{i18n:e,_:s}=g();w(e._({id:`zFuG9J`}));let b=y.graphQLClient.client,S=a(P,{client:b,variables:{inLibraryOnly:!1}}),k=a(N,{client:b}),F={client:b,refetchQueries:[P,N]},[I,L]=o(A,F),[R,z]=o(j,F),[B,V]=o(M,F),[H,U]=(0,O.useState)(null),[W,G]=(0,O.useState)(``),K=(0,O.useMemo)(()=>{let e=new Map;return k.data?.scanlatorAliases.nodes.forEach(t=>{e.set(t.scanlator,{id:t.id,displayName:t.displayName})}),e},[k.data]),q=(0,O.useMemo)(()=>{let e=new Set(S.data?.distinctScanlators.map(e=>e.scanlator));return(k.data?.scanlatorAliases.nodes??[]).filter(t=>!e.has(t.scanlator))},[k.data,S.data]),J=e=>{U(e),G(e.displayName)},Y=()=>{U(null),G(``)},X=async()=>{if(!H)return;let e=W.trim();e&&(H.aliasId==null?await I({variables:{input:{scanlator:H.scanlator,displayName:e}}}):await R({variables:{input:{id:H.aliasId,patch:{displayName:e}}}}),Y())},Z=async e=>{await B({variables:{input:{id:e}}})},Q=S.loading||k.loading,$=L.error??z.error??V.error;return(0,D.jsxs)(_,{sx:{p:2},children:[(0,D.jsx)(m,{variant:`body2`,color:`text.secondary`,sx:{mb:2},children:e._({id:`26Osr6`})}),$&&(0,D.jsx)(p,{severity:`error`,sx:{mb:2},children:$.message}),Q?(0,D.jsx)(_,{sx:{display:`flex`,justifyContent:`center`,p:4},children:(0,D.jsx)(ee,{})}):(0,D.jsxs)(i,{sx:{pt:0},subheader:(0,D.jsx)(C,{disableSticky:!0,children:e._({id:`FOIBn8`})}),children:[(S.data?.distinctScanlators??[]).length===0&&(0,D.jsx)(c,{children:(0,D.jsx)(x,{primary:e._({id:`l2JaIU`}),secondary:e._({id:`YCdfoq`})})}),(S.data?.distinctScanlators??[]).map(t=>{let n=K.get(t.scanlator);return(0,D.jsx)(c,{secondaryAction:(0,D.jsxs)(l,{direction:`row`,spacing:.5,children:[(0,D.jsx)(h,{title:n?e._({id:`1yF_rE`}):e._({id:`THpQth`}),children:(0,D.jsx)(d,{edge:`end`,onClick:()=>J({scanlator:t.scanlator,aliasId:n?.id,displayName:n?.displayName??t.scanlator}),children:(0,D.jsx)(E,{})})}),n&&(0,D.jsx)(h,{title:e._({id:`CE5-01`}),children:(0,D.jsx)(d,{edge:`end`,onClick:()=>Z(n.id),children:(0,D.jsx)(T,{})})})]}),children:(0,D.jsx)(x,{primary:n?`${n.displayName} → ${t.scanlator}`:t.scanlator,secondary:e._({id:`A5vgLW`,values:{0:t.chapterCount}})})},t.scanlator)}),q.length>0&&(0,D.jsxs)(D.Fragment,{children:[(0,D.jsx)(C,{disableSticky:!0,children:e._({id:`fWvx3Q`})}),(0,D.jsx)(c,{children:(0,D.jsx)(x,{secondary:e._({id:`YlOWam`})})}),q.map(t=>(0,D.jsx)(c,{secondaryAction:(0,D.jsxs)(l,{direction:`row`,spacing:.5,children:[(0,D.jsx)(h,{title:e._({id:`1yF_rE`}),children:(0,D.jsx)(d,{edge:`end`,onClick:()=>J({scanlator:t.scanlator,aliasId:t.id,displayName:t.displayName}),children:(0,D.jsx)(E,{})})}),(0,D.jsx)(h,{title:e._({id:`CE5-01`}),children:(0,D.jsx)(d,{edge:`end`,onClick:()=>Z(t.id),children:(0,D.jsx)(T,{})})})]}),children:(0,D.jsx)(x,{primary:`${t.displayName} → ${t.scanlator}`})},t.id))]})]}),(0,D.jsxs)(v,{open:H!=null,onClose:Y,fullWidth:!0,maxWidth:`sm`,children:[(0,D.jsx)(u,{children:H?.aliasId==null?e._({id:`GRdzxf`}):e._({id:`mwk3Lz`})}),(0,D.jsxs)(n,{children:[(0,D.jsx)(m,{variant:`body2`,color:`text.secondary`,sx:{mb:2},children:e._({id:`XLtJxm`,values:{0:H?.scanlator??``}})}),(0,D.jsx)(t,{autoFocus:!0,fullWidth:!0,label:e._({id:`pfa8F0`}),value:W,onChange:e=>G(e.target.value),onKeyDown:e=>{e.key===`Enter`&&(e.preventDefault(),X())}})]}),(0,D.jsxs)(r,{children:[(0,D.jsx)(f,{onClick:Y,children:e._({id:`dEgA5A`})}),(0,D.jsx)(f,{variant:`contained`,onClick:X,disabled:!W.trim(),children:e._({id:`tfDRzk`})})]})]})]})}export{F as ScanlatorAliases};