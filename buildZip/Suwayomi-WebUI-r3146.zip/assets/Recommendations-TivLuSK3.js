import{D as e,Hi as t,_a as n,co as r,en as i,ha as a,ji as o,ls as s,ma as c,po as l,xs as u}from"./index-BAr3COf8.js";import{t as d}from"./useAppTitle-BM0eceLP.js";import{t as f}from"./CardActionArea-DB0vXllm.js";import{t as p}from"./Card-BYCXOkzj.js";import{t as m}from"./CardContent-qA38ysjG.js";import{t as h}from"./Avatar-qvbE7Lq8.js";var g=u(),_=s`
    fragment RECOMMENDATION_FIELDS on RecommendationEntry {
        anilistId
        title
        coverUrl
        description
        genres
        averageScore
        rating
        anilistUrl
        sourceMangaId
        sourceMangaTitle
    }
`;s`
    ${_}
    query GET_MANGA_RECOMMENDATIONS($mangaId: Int!) {
        mangaRecommendations(mangaId: $mangaId) {
            ...RECOMMENDATION_FIELDS
        }
    }
`;var v=s`
    ${_}
    query GET_LIBRARY_RECOMMENDATIONS($perMangaLimit: Int, $totalLimit: Int) {
        libraryRecommendations(perMangaLimit: $perMangaLimit, totalLimit: $totalLimit) {
            ...RECOMMENDATION_FIELDS
        }
    }
`,y=e=>e?e.replace(/<[^>]+>/g,``).trim():``;function b(){let{i18n:s,_:u}=r();d(s._({id:`FXN0ro`}));let _=i.graphQLClient.client,{data:b,loading:x,error:S}=o(v,{client:_,variables:{perMangaLimit:5,totalLimit:60},fetchPolicy:`cache-and-network`}),C=b?.libraryRecommendations??[];return(0,g.jsxs)(l,{sx:{p:2,maxWidth:1100,mx:`auto`},children:[(0,g.jsx)(c,{variant:`body2`,color:`text.secondary`,sx:{mb:2},children:s._({id:`ZAQ1Uu`})}),x&&(0,g.jsx)(l,{sx:{display:`flex`,justifyContent:`center`,py:4},children:(0,g.jsx)(n,{})}),S&&(0,g.jsx)(a,{severity:`error`,sx:{mb:2},children:S.message}),!x&&!S&&C.length===0&&(0,g.jsx)(a,{severity:`info`,children:s._({id:`JFG_EH`})}),(0,g.jsx)(t,{spacing:1,children:C.map(n=>(0,g.jsx)(p,{children:(0,g.jsxs)(f,{component:`a`,href:n.anilistUrl??`https://anilist.co/manga/${n.anilistId}`,target:`_blank`,rel:`noopener`,sx:{display:`flex`,alignItems:`stretch`},children:[(0,g.jsx)(h,{variant:`rounded`,src:n.coverUrl??void 0,alt:n.title,sx:{width:80,height:120,m:1,flexShrink:0,bgcolor:`background.default`}}),(0,g.jsxs)(m,{sx:{flex:1,minWidth:0},children:[(0,g.jsxs)(t,{direction:`row`,spacing:1,sx:{alignItems:`baseline`,flexWrap:`wrap`},children:[(0,g.jsx)(c,{variant:`subtitle1`,sx:{flex:1,minWidth:0},noWrap:!0,children:n.title}),typeof n.averageScore==`number`&&(0,g.jsx)(e,{size:`small`,label:`★ ${n.averageScore}`}),typeof n.rating==`number`&&n.rating>0&&(0,g.jsx)(e,{size:`small`,variant:`outlined`,label:`+${n.rating}`})]}),n.sourceMangaTitle&&(0,g.jsx)(c,{variant:`caption`,color:`text.secondary`,children:s._({id:`7rY8Sk`,values:{0:n.sourceMangaTitle}})}),n.genres&&n.genres.length>0&&(0,g.jsx)(c,{variant:`body2`,color:`text.secondary`,sx:{mt:.5},noWrap:!0,children:n.genres.join(`, `)}),n.description&&(0,g.jsx)(c,{variant:`body2`,color:`text.secondary`,sx:{mt:.5,display:`-webkit-box`,WebkitLineClamp:3,WebkitBoxOrient:`vertical`,overflow:`hidden`},children:y(n.description)})]})]})},n.anilistId))})]})}export{b as Recommendations};