import{D as e,Hi as t,It as n,Mi as r,St as i,_a as a,an as o,as as s,co as c,en as l,ha as u,ji as d,ls as f,ma as p,po as m,ua as h,wt as g,xs as _}from"./index-BAr3COf8.js";import{t as v}from"./useAppTitle-BM0eceLP.js";var y=_(),b=f`
    query GET_LOCAL_SOURCE_ENTRIES {
        localSourceEntries {
            name
            type
            sizeBytes
            itemCount
            lastModified
        }
    }
`,x=f`
    mutation RESCAN_LOCAL_SOURCE($input: RescanLocalSourceInput!) {
        rescanLocalSource(input: $input) {
            imported
        }
    }
`,S=e=>{if(e<1024)return`${e} B`;let t=[`KB`,`MB`,`GB`,`TB`],n=e/1024,r=0;for(;n>=1024&&r<t.length-1;)n/=1024,r+=1;return`${n.toFixed(1)} ${t[r]}`};function C(){let{i18n:f,_}=c();v(f._({id:`LECJgZ`}));let C=l.graphQLClient.client,{data:w,loading:T,error:E,refetch:D}=d(b,{client:C,fetchPolicy:`cache-and-network`}),[O,k]=r(x,{client:C}),A=w?.localSourceEntries??[];return(0,y.jsxs)(m,{sx:{p:2},children:[(0,y.jsxs)(t,{direction:`row`,spacing:1,sx:{mb:2,alignItems:`center`},children:[(0,y.jsx)(p,{variant:`body2`,color:`text.secondary`,sx:{flex:1},children:f._({id:`1746P2`})}),(0,y.jsx)(h,{variant:`contained`,onClick:async()=>{try{let e=(await O({variables:{input:{}}})).data?.rescanLocalSource?.imported??0;o(f._({id:`L-RWYf`,values:{count:e}}),`success`),D().catch(()=>{})}catch(e){o(f._({id:`gVINQc`}),`error`,s(e))}},disabled:k.loading,children:f._({id:`Igjjz3`})})]}),E&&(0,y.jsx)(u,{severity:`error`,sx:{mb:2},children:E.message}),k.error&&(0,y.jsx)(u,{severity:`error`,sx:{mb:2},children:k.error.message}),T?(0,y.jsx)(m,{sx:{display:`flex`,justifyContent:`center`,p:4},children:(0,y.jsx)(a,{})}):A.length===0?(0,y.jsx)(u,{severity:`info`,children:f._({id:`MY0lRL`})}):(0,y.jsx)(n,{sx:{pt:0},children:A.map(n=>(0,y.jsx)(i,{secondaryAction:(0,y.jsxs)(t,{direction:`row`,spacing:.5,children:[(0,y.jsx)(e,{size:`small`,label:n.type}),(0,y.jsx)(e,{size:`small`,variant:`outlined`,label:S(Number(n.sizeBytes))})]}),children:(0,y.jsx)(g,{primary:n.name,secondary:n.type===`folder`?f._({id:`nO9aok`,values:{0:n.itemCount,1:new Date(Number(n.lastModified)).toLocaleString()}}):f._({id:`csbOd5`,values:{0:new Date(Number(n.lastModified)).toLocaleString()}})})},n.name))})]})}export{C as LocalSourceTools};