import{r as e}from"./chunk-CilyBKbf.js";import{F as t,Fi as n,Hi as r,Ii as i,Ni as a,Pi as o,Vt as s,_a as c,bs as l,co as u,en as d,go as f,gs as p,hs as m,ls as h,ma as g,ms as _,po as v,ps as y,ua as b,us as x,xs as S}from"./index-BAr3COf8.js";import{t as C}from"./useAppTitle-BM0eceLP.js";import{t as w}from"./FormGroup-CZngvVja.js";import{n as T,t as E}from"./FormControlLabel-BWvxinQ1.js";import{t as D}from"./CardActionArea-DB0vXllm.js";import{t as O}from"./Card-BYCXOkzj.js";import{t as k}from"./CardContent-qA38ysjG.js";import{t as A}from"./Avatar-qvbE7Lq8.js";var j=e(l(),1),M;function N(){}function P(){return M||(M=j.createContext(null)),j.useCallback(()=>{let e=console.error;try{return console.error=N,j.useContext(M),!0}catch{return!1}finally{console.error=e}},[])}var F=[`refetch`,`fetchMore`,`updateQuery`,`startPolling`,`stopPolling`,`subscribeToMore`];function I(e,t){let r=i(t?.client),s=j.useRef(void 0),c=j.useRef(void 0),l=n(()=>t,[t]),u=P();function d(){return r.watchQuery({...t,query:e,initialFetchPolicy:t?.fetchPolicy,fetchPolicy:`standby`,[y]:!0})}let[f,m]=j.useState(r),[h,g]=j.useState(d);f!==r&&(m(r),g(d()));let v=j.useCallback((e,t)=>{let n=c.current?.data;n&&!_(n,e.data)&&(s.current=n),c.current=e,t()},[]),b=a(j.useCallback(e=>{let t=h.subscribe(t=>{_(c.current,t)||v(t,e)});return()=>{t.unsubscribe()}},[h,v]),()=>c.current||L,()=>L),x=j.useMemo(()=>{let e={};for(let t of F)e[t]=function(...e){return p(c.current,29,t),h[t](...e)};return e},[h]);j.useEffect(()=>{let n={query:e,errorPolicy:l?.errorPolicy,refetchWritePolicy:l?.refetchWritePolicy,returnPartialData:l?.returnPartialData,notifyOnNetworkStatusChange:l?.notifyOnNetworkStatusChange,nextFetchPolicy:t?.nextFetchPolicy,skipPollAttempt:t?.skipPollAttempt};h.options.fetchPolicy!==`standby`&&l?.fetchPolicy&&(n.fetchPolicy=l.fetchPolicy),h.applyOptions(n)},[e,h,l,t?.nextFetchPolicy,t?.skipPollAttempt]);let S=j.useCallback((...e)=>{p(!u(),30);let[t]=e,n=h.options.fetchPolicy;return n===`standby`&&(n=h.options.initialFetchPolicy),h.reobserve({fetchPolicy:n,variables:t?.variables,context:t?.context??{}})},[h,u]),C=j.useRef(S);return o(()=>{C.current=S}),[j.useCallback((...e)=>C.current(...e),[]),j.useMemo(()=>{let{partial:e,...t}=b;return{...x,...t,client:r,previousData:s.current,variables:h.variables,observable:h,called:!!c.current}},[r,b,x,h])]}var L=m({data:void 0,dataState:`empty`,loading:!1,networkStatus:x.ready,partial:!0}),R=S(),z=h`
    query SEARCH_LIBRARY(
        $query: String!
        $inLibraryOnly: Boolean
        $searchTitle: Boolean
        $searchAuthor: Boolean
        $searchArtist: Boolean
        $searchDescription: Boolean
        $searchGenre: Boolean
        $limit: Int
    ) {
        searchLibrary(
            query: $query
            inLibraryOnly: $inLibraryOnly
            searchTitle: $searchTitle
            searchAuthor: $searchAuthor
            searchArtist: $searchArtist
            searchDescription: $searchDescription
            searchGenre: $searchGenre
            limit: $limit
        ) {
            id
            title
            author
            artist
            inLibrary
            thumbnailUrl
            genre
            sourceId
            source {
                id
                name
                displayName
                lang
            }
        }
    }
`;function B(){let{i18n:e,_:n}=u();C(e._({id:`5DDGaT`}));let i=d.graphQLClient.client,[a,o]=(0,j.useState)(``),[l,p]=(0,j.useState)(!0),[m,h]=(0,j.useState)(!0),[_,y]=(0,j.useState)(!0),[x,S]=(0,j.useState)(!1),[M,N]=(0,j.useState)(!1),[P,F]=(0,j.useState)(!0),[L,{data:B,loading:V,error:H}]=I(z,{client:i,fetchPolicy:`network-only`}),U=e=>{e.preventDefault();let t=a.trim();t&&L({variables:{query:t,inLibraryOnly:l,searchTitle:m,searchAuthor:_,searchArtist:x,searchDescription:M,searchGenre:P,limit:200}})},W=B?.searchLibrary??[],G=(0,j.useMemo)(()=>!m&&!_&&!x&&!M&&!P,[m,_,x,M,P]);return(0,R.jsxs)(v,{sx:{p:2,maxWidth:960,mx:`auto`},children:[(0,R.jsx)(g,{variant:`body2`,color:`text.secondary`,sx:{mb:2},children:e._({id:`kZ5R5Y`})}),(0,R.jsx)(v,{component:`form`,onSubmit:U,children:(0,R.jsxs)(r,{spacing:2,children:[(0,R.jsx)(t,{autoFocus:!0,fullWidth:!0,label:e._({id:`0mx5ow`}),placeholder:e._({id:`8n8Bag`}),value:a,onChange:e=>o(e.target.value)}),(0,R.jsx)(w,{row:!0,children:(0,R.jsx)(E,{control:(0,R.jsx)(T,{checked:l,onChange:e=>p(e.target.checked)}),label:e._({id:`nKqcBE`})})}),(0,R.jsxs)(v,{children:[(0,R.jsx)(g,{variant:`body2`,color:`text.secondary`,sx:{mb:1},children:e._({id:`8MYSKY`})}),(0,R.jsxs)(w,{row:!0,children:[(0,R.jsx)(E,{control:(0,R.jsx)(T,{checked:m,onChange:e=>h(e.target.checked)}),label:e._({id:`MHrjPM`})}),(0,R.jsx)(E,{control:(0,R.jsx)(T,{checked:_,onChange:e=>y(e.target.checked)}),label:e._({id:`VbeIOx`})}),(0,R.jsx)(E,{control:(0,R.jsx)(T,{checked:x,onChange:e=>S(e.target.checked)}),label:e._({id:`0s5Sjx`})}),(0,R.jsx)(E,{control:(0,R.jsx)(T,{checked:P,onChange:e=>F(e.target.checked)}),label:e._({id:`svIAT3`})}),(0,R.jsx)(E,{control:(0,R.jsx)(T,{checked:M,onChange:e=>N(e.target.checked)}),label:e._({id:`Nu4oKW`})})]})]}),(0,R.jsx)(b,{type:`submit`,variant:`contained`,disabled:!a.trim()||G||V,children:e._({id:`A1taO8`})})]})}),V&&(0,R.jsx)(v,{sx:{display:`flex`,justifyContent:`center`,mt:3},children:(0,R.jsx)(c,{})}),H&&(0,R.jsx)(g,{color:`error`,sx:{mt:2},children:H.message}),!V&&B&&(0,R.jsxs)(v,{sx:{mt:3},children:[(0,R.jsx)(g,{variant:`subtitle2`,sx:{mb:1},children:e._({id:`WHRNSh`,values:{0:W.length}})}),(0,R.jsx)(r,{spacing:1,children:W.map(t=>{let n=t.thumbnailUrl?d.getValidImgUrlFor(t.thumbnailUrl):void 0,r=t.source?`${t.source.displayName??t.source.name}${t.source.lang?` · ${t.source.lang}`:``}`:e._({id:`g8p10I`});return(0,R.jsx)(O,{children:(0,R.jsxs)(D,{component:f,to:s.manga.path(t.id),sx:{display:`flex`,alignItems:`stretch`},children:[(0,R.jsx)(A,{variant:`rounded`,src:n,alt:t.title,sx:{width:64,height:96,m:1,flexShrink:0,bgcolor:`background.default`}}),(0,R.jsxs)(k,{sx:{flex:1,minWidth:0},children:[(0,R.jsx)(g,{variant:`subtitle1`,noWrap:!0,children:t.title}),(0,R.jsx)(g,{variant:`caption`,color:`text.secondary`,sx:{display:`block`},children:r}),t.author&&(0,R.jsxs)(g,{variant:`body2`,color:`text.secondary`,noWrap:!0,children:[t.author,t.artist&&t.artist!==t.author?` · ${t.artist}`:``]}),t.genre&&t.genre.length>0&&(0,R.jsx)(g,{variant:`body2`,color:`text.secondary`,noWrap:!0,children:t.genre.join(`, `)})]})]})},t.id)})})]})]})}export{B as AdvancedLibrarySearch};