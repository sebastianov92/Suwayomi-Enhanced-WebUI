import{us as e}from"./index-QBqlZCL5.js";var t=e`
    query GET_KINDLE_QUEUE {
        kindleQueue {
            id
            chapterId
            mangaId
            mangaTitle
            chapterName
            status
            attempts
            triggerSource
            destination
            lastError
            enqueuedAt
            lastAttemptAt
            nextAttemptAt
        }
    }
`,n=e`
    query GET_EMAIL_PRESETS {
        emailPresets {
            id
            displayName
            host
            port
            useStartTls
        }
    }
`,r=e`
    query GET_MANGA_KINDLE_CONFIG($mangaId: Int!) {
        mangaKindleConfig(mangaId: $mangaId) {
            mangaId
            autoSend
            destination
        }
    }
`;export{t as n,r,n as t};