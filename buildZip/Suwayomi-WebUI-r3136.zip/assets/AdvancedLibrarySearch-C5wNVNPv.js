import{r as e}from"./chunk-CilyBKbf.js";import{F as t,Fi as n,Ht as r,Ii as i,Li as a,Pi as o,Ss as s,Ui as c,_o as l,_s as u,da as d,ds as f,gs as p,ha as m,hs as h,lo as g,mo as _,ms as v,tn as y,us as b,va as x,xs as S}from"./index-Dj2pGDWR.js";import{t as C}from"./useAppTitle-BEyRWi2I.js";import{t as w}from"./FormGroup-CVhj_jBj.js";import{n as T,t as E}from"./FormControlLabel-t_OJ1Rx3.js";import{t as D}from"./CardActionArea-HPQQ3lSY.js";import{t as O}from"./Card-D8zp33Hn.js";import{t as k}from"./CardContent-D9mdFB0Z.js";import{t as A}from"./Avatar-6PLPWxgy.js";var j=e(S(),1),M;function N(){}function P(){return M||(M=j.createContext(null)),j.useCallback(()=>{let e=console.error;try{return console.error=N,j.useContext(M),!0}catch{return!1}finally{console.error=e}},[])}var F=[`refetch`,`fetchMore`,`updateQuery`,`startPolling`,`stopPolling`,`subscribeToMore`];function I(e,t){let r=a(t?.client),s=j.useRef(void 0),c=j.useRef(void 0),l=i(()=>t,[t]),d=P();function f(){return r.watchQuery({...t,query:e,initialFetchPolicy:t?.fetchPolicy,fetchPolicy:`standby`,[v]:!0})}let[p,m]=j.useState(r),[g,_]=j.useState(f);p!==r&&(m(r),_(f()));let y=j.useCallback((e,t)=>{let n=c.current?.data;n&&!h(n,e.data)&&(s.current=n),c.current=e,t()},[]),b=o(j.useCallback(e=>{let t=g.subscribe(t=>{h(c.current,t)||y(t,e)});return()=>{t.unsubscribe()}},[g,y]),()=>c.current||L,()=>L),x=j.useMemo(()=>{let e={};for(let t of F)e[t]=function(...e){return u(c.current,29,t),g[t](...e)};return e},[g]);j.useEffect(()=>{let n={query:e,errorPolicy:l?.errorPolicy,refetchWritePolicy:l?.refetchWritePolicy,returnPartialData:l?.returnPartialData,notifyOnNetworkStatusChange:l?.notifyOnNetworkStatusChange,nextFetchPolicy:t?.nextFetchPolicy,skipPollAttempt:t?.skipPollAttempt};g.options.fetchPolicy!==`standby`&&l?.fetchPolicy&&(n.fetchPolicy=l.fetchPolicy),g.applyOptions(n)},[e,g,l,t?.nextFetchPolicy,t?.skipPollAttempt]);let S=j.useCallback((...e)=>{u(!d(),30);let[t]=e,n=g.options.fetchPolicy;return n===`standby`&&(n=g.options.initialFetchPolicy),g.reobserve({fetchPolicy:n,variables:t?.variables,context:t?.context??{}})},[g,d]),C=j.useRef(S);return n(()=>{C.current=S}),[j.useCallback((...e)=>C.current(...e),[]),j.useMemo(()=>{let{partial:e,...t}=b;return{...x,...t,client:r,previousData:s.current,variables:g.variables,observable:g,called:!!c.current}},[r,b,x,g])]}var L=p({data:void 0,dataState:`empty`,loading:!1,networkStatus:f.ready,partial:!0}),R=s(),z=b`
    query SEARCH_LIBRARY(
        $query: String!
        $inLibraryOnly: Boolean
        $searchTitle: Boolean
        $searchAuthor: Boolean
        $searchArtist: Boolean
        $searchDescription: Boolean
        $searchGenre: Boolean
        $limit: Int
    ) {
        searchLibrary(
            query: $query
            inLibraryOnly: $inLibraryOnly
            searchTitle: $searchTitle
            searchAuthor: $searchAuthor
            searchArtist: $searchArtist
            searchDescription: $searchDescription
            searchGenre: $searchGenre
            limit: $limit
        ) {
            id
            title
            author
            artist
            inLibrary
            thumbnailUrl
            genre
            sourceId
            source {
                id
                name
                displayName
                lang
            }
        }
    }
`;function B(){let{i18n:e,_:n}=g();C(e._({id:`5DDGaT`}));let i=y.graphQLClient.client,[a,o]=(0,j.useState)(``),[s,u]=(0,j.useState)(!0),[f,p]=(0,j.useState)(!0),[h,v]=(0,j.useState)(!0),[b,S]=(0,j.useState)(!1),[M,N]=(0,j.useState)(!1),[P,F]=(0,j.useState)(!0),[L,{data:B,loading:V,error:H}]=I(z,{client:i,fetchPolicy:`network-only`}),U=e=>{e.preventDefault();let t=a.trim();t&&L({variables:{query:t,inLibraryOnly:s,searchTitle:f,searchAuthor:h,searchArtist:b,searchDescription:M,searchGenre:P,limit:200}})},W=B?.searchLibrary??[],G=(0,j.useMemo)(()=>!f&&!h&&!b&&!M&&!P,[f,h,b,M,P]);return(0,R.jsxs)(_,{sx:{p:2,maxWidth:960,mx:`auto`},children:[(0,R.jsx)(m,{variant:`body2`,color:`text.secondary`,sx:{mb:2},children:e._({id:`kZ5R5Y`})}),(0,R.jsx)(_,{component:`form`,onSubmit:U,children:(0,R.jsxs)(c,{spacing:2,children:[(0,R.jsx)(t,{autoFocus:!0,fullWidth:!0,label:e._({id:`0mx5ow`}),placeholder:e._({id:`8n8Bag`}),value:a,onChange:e=>o(e.target.value)}),(0,R.jsx)(w,{row:!0,children:(0,R.jsx)(E,{control:(0,R.jsx)(T,{checked:s,onChange:e=>u(e.target.checked)}),label:e._({id:`nKqcBE`})})}),(0,R.jsxs)(_,{children:[(0,R.jsx)(m,{variant:`body2`,color:`text.secondary`,sx:{mb:1},children:e._({id:`8MYSKY`})}),(0,R.jsxs)(w,{row:!0,children:[(0,R.jsx)(E,{control:(0,R.jsx)(T,{checked:f,onChange:e=>p(e.target.checked)}),label:e._({id:`MHrjPM`})}),(0,R.jsx)(E,{control:(0,R.jsx)(T,{checked:h,onChange:e=>v(e.target.checked)}),label:e._({id:`VbeIOx`})}),(0,R.jsx)(E,{control:(0,R.jsx)(T,{checked:b,onChange:e=>S(e.target.checked)}),label:e._({id:`0s5Sjx`})}),(0,R.jsx)(E,{control:(0,R.jsx)(T,{checked:P,onChange:e=>F(e.target.checked)}),label:e._({id:`svIAT3`})}),(0,R.jsx)(E,{control:(0,R.jsx)(T,{checked:M,onChange:e=>N(e.target.checked)}),label:e._({id:`Nu4oKW`})})]})]}),(0,R.jsx)(d,{type:`submit`,variant:`contained`,disabled:!a.trim()||G||V,children:e._({id:`A1taO8`})})]})}),V&&(0,R.jsx)(_,{sx:{display:`flex`,justifyContent:`center`,mt:3},children:(0,R.jsx)(x,{})}),H&&(0,R.jsx)(m,{color:`error`,sx:{mt:2},children:H.message}),!V&&B&&(0,R.jsxs)(_,{sx:{mt:3},children:[(0,R.jsx)(m,{variant:`subtitle2`,sx:{mb:1},children:e._({id:`WHRNSh`,values:{0:W.length}})}),(0,R.jsx)(c,{spacing:1,children:W.map(t=>{let n=t.thumbnailUrl?y.getValidImgUrlFor(t.thumbnailUrl):void 0,i=t.source?`${t.source.displayName??t.source.name}${t.source.lang?` · ${t.source.lang}`:``}`:e._({id:`g8p10I`});return(0,R.jsx)(O,{children:(0,R.jsxs)(D,{component:l,to:r.manga.path(t.id),sx:{display:`flex`,alignItems:`stretch`},children:[(0,R.jsx)(A,{variant:`rounded`,src:n,alt:t.title,sx:{width:64,height:96,m:1,flexShrink:0,bgcolor:`background.default`}}),(0,R.jsxs)(k,{sx:{flex:1,minWidth:0},children:[(0,R.jsx)(m,{variant:`subtitle1`,noWrap:!0,children:t.title}),(0,R.jsx)(m,{variant:`caption`,color:`text.secondary`,sx:{display:`block`},children:i}),t.author&&(0,R.jsxs)(m,{variant:`body2`,color:`text.secondary`,noWrap:!0,children:[t.author,t.artist&&t.artist!==t.author?` · ${t.artist}`:``]}),t.genre&&t.genre.length>0&&(0,R.jsx)(m,{variant:`body2`,color:`text.secondary`,noWrap:!0,children:t.genre.join(`, `)})]})]})},t.id)})})]})]})}export{B as AdvancedLibrarySearch};