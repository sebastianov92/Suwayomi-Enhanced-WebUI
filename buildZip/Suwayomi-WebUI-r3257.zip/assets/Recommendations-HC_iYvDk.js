import{$t as e,Ai as t,E as n,Vi as r,bs as i,cs as a,fo as o,ga as s,ma as c,pa as l,so as u}from"./index-D6X9ubOn.js";import{t as d}from"./useAppTitle-Ca6NCV5j.js";import{t as f}from"./CardActionArea-wVYIGEfN.js";import{t as p}from"./Card-B-xk6NW7.js";import{t as m}from"./CardContent-DARVjO4v.js";import{t as h}from"./Avatar-BMwdpX1x.js";var g=i(),_=a`
    fragment RECOMMENDATION_FIELDS on RecommendationEntry {
        anilistId
        title
        coverUrl
        description
        genres
        averageScore
        rating
        anilistUrl
        sourceMangaId
        sourceMangaTitle
    }
`;a`
    ${_}
    query GET_MANGA_RECOMMENDATIONS($mangaId: Int!) {
        mangaRecommendations(mangaId: $mangaId) {
            ...RECOMMENDATION_FIELDS
        }
    }
`;var v=a`
    ${_}
    query GET_LIBRARY_RECOMMENDATIONS($perMangaLimit: Int, $totalLimit: Int) {
        libraryRecommendations(perMangaLimit: $perMangaLimit, totalLimit: $totalLimit) {
            ...RECOMMENDATION_FIELDS
        }
    }
`,y=e=>e?e.replace(/<[^>]+>/g,``).trim():``;function b(){let{i18n:i,_:a}=u();d(i._({id:`FXN0ro`}));let _=e.graphQLClient.client,{data:b,loading:x,error:S}=t(v,{client:_,variables:{perMangaLimit:5,totalLimit:60},fetchPolicy:`cache-and-network`}),C=b?.libraryRecommendations??[];return(0,g.jsxs)(o,{sx:{p:2,maxWidth:1100,mx:`auto`},children:[(0,g.jsx)(l,{variant:`body2`,color:`text.secondary`,sx:{mb:2},children:i._({id:`ZAQ1Uu`})}),x&&(0,g.jsx)(o,{sx:{display:`flex`,justifyContent:`center`,py:4},children:(0,g.jsx)(s,{})}),S&&(0,g.jsx)(c,{severity:`error`,sx:{mb:2},children:S.message}),!x&&!S&&C.length===0&&(0,g.jsx)(c,{severity:`info`,children:i._({id:`JFG_EH`})}),(0,g.jsx)(r,{spacing:1,children:C.map(e=>(0,g.jsx)(p,{children:(0,g.jsxs)(f,{component:`a`,href:e.anilistUrl??`https://anilist.co/manga/${e.anilistId}`,target:`_blank`,rel:`noopener`,sx:{display:`flex`,alignItems:`stretch`},children:[(0,g.jsx)(h,{variant:`rounded`,src:e.coverUrl??void 0,alt:e.title,sx:{width:80,height:120,m:1,flexShrink:0,bgcolor:`background.default`}}),(0,g.jsxs)(m,{sx:{flex:1,minWidth:0},children:[(0,g.jsxs)(r,{direction:`row`,spacing:1,sx:{alignItems:`baseline`,flexWrap:`wrap`},children:[(0,g.jsx)(l,{variant:`subtitle1`,sx:{flex:1,minWidth:0},noWrap:!0,children:e.title}),typeof e.averageScore==`number`&&(0,g.jsx)(n,{size:`small`,label:`★ ${e.averageScore}`}),typeof e.rating==`number`&&e.rating>0&&(0,g.jsx)(n,{size:`small`,variant:`outlined`,label:`+${e.rating}`})]}),e.sourceMangaTitle&&(0,g.jsx)(l,{variant:`caption`,color:`text.secondary`,children:i._({id:`7rY8Sk`,values:{0:e.sourceMangaTitle}})}),e.genres&&e.genres.length>0&&(0,g.jsx)(l,{variant:`body2`,color:`text.secondary`,sx:{mt:.5},noWrap:!0,children:e.genres.join(`, `)}),e.description&&(0,g.jsx)(l,{variant:`body2`,color:`text.secondary`,sx:{mt:.5,display:`-webkit-box`,WebkitLineClamp:3,WebkitBoxOrient:`vertical`,overflow:`hidden`},children:y(e.description)})]})]})},e.anilistId))})]})}export{b as Recommendations};