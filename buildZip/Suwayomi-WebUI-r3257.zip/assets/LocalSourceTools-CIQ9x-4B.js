import{$t as e,Ai as t,Ct as n,E as r,Ft as i,Vi as a,bs as o,cs as s,fo as c,ga as l,in as u,is as d,ji as f,la as p,ma as m,pa as h,so as g,xt as _}from"./index-D6X9ubOn.js";import{t as v}from"./useAppTitle-Ca6NCV5j.js";var y=o(),b=s`
    query GET_LOCAL_SOURCE_ENTRIES {
        localSourceEntries {
            name
            type
            sizeBytes
            itemCount
            lastModified
        }
    }
`,x=s`
    mutation RESCAN_LOCAL_SOURCE($input: RescanLocalSourceInput!) {
        rescanLocalSource(input: $input) {
            imported
        }
    }
`,S=e=>{if(e<1024)return`${e} B`;let t=[`KB`,`MB`,`GB`,`TB`],n=e/1024,r=0;for(;n>=1024&&r<t.length-1;)n/=1024,r+=1;return`${n.toFixed(1)} ${t[r]}`};function C(){let{i18n:o,_:s}=g();v(o._({id:`LECJgZ`}));let C=e.graphQLClient.client,{data:w,loading:T,error:E,refetch:D}=t(b,{client:C,fetchPolicy:`cache-and-network`}),[O,k]=f(x,{client:C}),A=w?.localSourceEntries??[];return(0,y.jsxs)(c,{sx:{p:2},children:[(0,y.jsxs)(a,{direction:`row`,spacing:1,sx:{mb:2,alignItems:`center`},children:[(0,y.jsx)(h,{variant:`body2`,color:`text.secondary`,sx:{flex:1},children:o._({id:`1746P2`})}),(0,y.jsx)(p,{variant:`contained`,onClick:async()=>{try{let e=(await O({variables:{input:{}}})).data?.rescanLocalSource?.imported??0;u(o._({id:`L-RWYf`,values:{count:e}}),`success`),D().catch(()=>{})}catch(e){u(o._({id:`gVINQc`}),`error`,d(e))}},disabled:k.loading,children:o._({id:`Igjjz3`})})]}),E&&(0,y.jsx)(m,{severity:`error`,sx:{mb:2},children:E.message}),k.error&&(0,y.jsx)(m,{severity:`error`,sx:{mb:2},children:k.error.message}),T?(0,y.jsx)(c,{sx:{display:`flex`,justifyContent:`center`,p:4},children:(0,y.jsx)(l,{})}):A.length===0?(0,y.jsx)(m,{severity:`info`,children:o._({id:`MY0lRL`})}):(0,y.jsx)(i,{sx:{pt:0},children:A.map(e=>(0,y.jsx)(_,{secondaryAction:(0,y.jsxs)(a,{direction:`row`,spacing:.5,children:[(0,y.jsx)(r,{size:`small`,label:e.type}),(0,y.jsx)(r,{size:`small`,variant:`outlined`,label:S(Number(e.sizeBytes))})]}),children:(0,y.jsx)(n,{primary:e.name,secondary:e.type===`folder`?o._({id:`nO9aok`,values:{0:e.itemCount,1:new Date(Number(e.lastModified)).toLocaleString()}}):o._({id:`csbOd5`,values:{0:new Date(Number(e.lastModified)).toLocaleString()}})})},e.name))})]})}export{C as LocalSourceTools};