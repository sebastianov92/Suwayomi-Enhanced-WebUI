import{r as e}from"./chunk-CilyBKbf.js";import{$t as t,Bt as n,Fi as r,Mi as i,Ni as a,P as o,Pi as s,Vi as c,bs as l,cs as u,fo as d,fs as f,ga as p,ho as m,hs as h,la as g,ls as _,ms as v,pa as y,ps as b,so as x,ys as S}from"./index-DfzuDFIg.js";import{t as C}from"./useAppTitle-DoP2j2C1.js";import{t as w}from"./FormGroup-C-_aoadd.js";import{n as T,t as E}from"./FormControlLabel-C3ocbWvy.js";import{t as D}from"./CardActionArea-E5pAXOtv.js";import{t as O}from"./Card-CqS1zWs0.js";import{t as k}from"./CardContent-cUnFJr_Z.js";import{t as A}from"./Avatar-CdbCGNKw.js";var j=e(S(),1),M;function N(){}function P(){return M||(M=j.createContext(null)),j.useCallback(()=>{let e=console.error;try{return console.error=N,j.useContext(M),!0}catch{return!1}finally{console.error=e}},[])}var F=[`refetch`,`fetchMore`,`updateQuery`,`startPolling`,`stopPolling`,`subscribeToMore`];function I(e,t){let n=r(t?.client),o=j.useRef(void 0),c=j.useRef(void 0),l=s(()=>t,[t]),u=P();function d(){return n.watchQuery({...t,query:e,initialFetchPolicy:t?.fetchPolicy,fetchPolicy:`standby`,[f]:!0})}let[p,m]=j.useState(n),[g,_]=j.useState(d);p!==n&&(m(n),_(d()));let v=j.useCallback((e,t)=>{let n=c.current?.data;n&&!b(n,e.data)&&(o.current=n),c.current=e,t()},[]),y=i(j.useCallback(e=>{let t=g.subscribe(t=>{b(c.current,t)||v(t,e)});return()=>{t.unsubscribe()}},[g,v]),()=>c.current||L,()=>L),x=j.useMemo(()=>{let e={};for(let t of F)e[t]=function(...e){return h(c.current,29,t),g[t](...e)};return e},[g]);j.useEffect(()=>{let n={query:e,errorPolicy:l?.errorPolicy,refetchWritePolicy:l?.refetchWritePolicy,returnPartialData:l?.returnPartialData,notifyOnNetworkStatusChange:l?.notifyOnNetworkStatusChange,nextFetchPolicy:t?.nextFetchPolicy,skipPollAttempt:t?.skipPollAttempt};g.options.fetchPolicy!==`standby`&&l?.fetchPolicy&&(n.fetchPolicy=l.fetchPolicy),g.applyOptions(n)},[e,g,l,t?.nextFetchPolicy,t?.skipPollAttempt]);let S=j.useCallback((...e)=>{h(!u(),30);let[t]=e,n=g.options.fetchPolicy;return n===`standby`&&(n=g.options.initialFetchPolicy),g.reobserve({fetchPolicy:n,variables:t?.variables,context:t?.context??{}})},[g,u]),C=j.useRef(S);return a(()=>{C.current=S}),[j.useCallback((...e)=>C.current(...e),[]),j.useMemo(()=>{let{partial:e,...t}=y;return{...x,...t,client:n,previousData:o.current,variables:g.variables,observable:g,called:!!c.current}},[n,y,x,g])]}var L=v({data:void 0,dataState:`empty`,loading:!1,networkStatus:_.ready,partial:!0}),R=l(),z=u`
    query SEARCH_LIBRARY(
        $query: String!
        $inLibraryOnly: Boolean
        $searchTitle: Boolean
        $searchAuthor: Boolean
        $searchArtist: Boolean
        $searchDescription: Boolean
        $searchGenre: Boolean
        $limit: Int
    ) {
        searchLibrary(
            query: $query
            inLibraryOnly: $inLibraryOnly
            searchTitle: $searchTitle
            searchAuthor: $searchAuthor
            searchArtist: $searchArtist
            searchDescription: $searchDescription
            searchGenre: $searchGenre
            limit: $limit
        ) {
            id
            title
            author
            artist
            inLibrary
            thumbnailUrl
            genre
            sourceId
            source {
                id
                name
                displayName
                lang
            }
        }
    }
`;function B(){let{i18n:e,_:r}=x();C(e._({id:`5DDGaT`}));let i=t.graphQLClient.client,[a,s]=(0,j.useState)(``),[l,u]=(0,j.useState)(!0),[f,h]=(0,j.useState)(!0),[_,v]=(0,j.useState)(!0),[b,S]=(0,j.useState)(!1),[M,N]=(0,j.useState)(!1),[P,F]=(0,j.useState)(!0),[L,{data:B,loading:V,error:H}]=I(z,{client:i,fetchPolicy:`network-only`}),U=e=>{e.preventDefault();let t=a.trim();t&&L({variables:{query:t,inLibraryOnly:l,searchTitle:f,searchAuthor:_,searchArtist:b,searchDescription:M,searchGenre:P,limit:200}})},W=B?.searchLibrary??[],G=(0,j.useMemo)(()=>!f&&!_&&!b&&!M&&!P,[f,_,b,M,P]);return(0,R.jsxs)(d,{sx:{p:2,maxWidth:960,mx:`auto`},children:[(0,R.jsx)(y,{variant:`body2`,color:`text.secondary`,sx:{mb:2},children:e._({id:`kZ5R5Y`})}),(0,R.jsx)(d,{component:`form`,onSubmit:U,children:(0,R.jsxs)(c,{spacing:2,children:[(0,R.jsx)(o,{autoFocus:!0,fullWidth:!0,label:e._({id:`0mx5ow`}),placeholder:e._({id:`8n8Bag`}),value:a,onChange:e=>s(e.target.value)}),(0,R.jsx)(w,{row:!0,children:(0,R.jsx)(E,{control:(0,R.jsx)(T,{checked:l,onChange:e=>u(e.target.checked)}),label:e._({id:`nKqcBE`})})}),(0,R.jsxs)(d,{children:[(0,R.jsx)(y,{variant:`body2`,color:`text.secondary`,sx:{mb:1},children:e._({id:`8MYSKY`})}),(0,R.jsxs)(w,{row:!0,children:[(0,R.jsx)(E,{control:(0,R.jsx)(T,{checked:f,onChange:e=>h(e.target.checked)}),label:e._({id:`MHrjPM`})}),(0,R.jsx)(E,{control:(0,R.jsx)(T,{checked:_,onChange:e=>v(e.target.checked)}),label:e._({id:`VbeIOx`})}),(0,R.jsx)(E,{control:(0,R.jsx)(T,{checked:b,onChange:e=>S(e.target.checked)}),label:e._({id:`0s5Sjx`})}),(0,R.jsx)(E,{control:(0,R.jsx)(T,{checked:P,onChange:e=>F(e.target.checked)}),label:e._({id:`svIAT3`})}),(0,R.jsx)(E,{control:(0,R.jsx)(T,{checked:M,onChange:e=>N(e.target.checked)}),label:e._({id:`Nu4oKW`})})]})]}),(0,R.jsx)(g,{type:`submit`,variant:`contained`,disabled:!a.trim()||G||V,children:e._({id:`A1taO8`})})]})}),V&&(0,R.jsx)(d,{sx:{display:`flex`,justifyContent:`center`,mt:3},children:(0,R.jsx)(p,{})}),H&&(0,R.jsx)(y,{color:`error`,sx:{mt:2},children:H.message}),!V&&B&&(0,R.jsxs)(d,{sx:{mt:3},children:[(0,R.jsx)(y,{variant:`subtitle2`,sx:{mb:1},children:e._({id:`WHRNSh`,values:{0:W.length}})}),(0,R.jsx)(c,{spacing:1,children:W.map(r=>{let i=r.thumbnailUrl?t.getValidImgUrlFor(r.thumbnailUrl):void 0,a=r.source?`${r.source.displayName??r.source.name}${r.source.lang?` · ${r.source.lang}`:``}`:e._({id:`g8p10I`});return(0,R.jsx)(O,{children:(0,R.jsxs)(D,{component:m,to:n.manga.path(r.id),sx:{display:`flex`,alignItems:`stretch`},children:[(0,R.jsx)(A,{variant:`rounded`,src:i,alt:r.title,sx:{width:64,height:96,m:1,flexShrink:0,bgcolor:`background.default`}}),(0,R.jsxs)(k,{sx:{flex:1,minWidth:0},children:[(0,R.jsx)(y,{variant:`subtitle1`,noWrap:!0,children:r.title}),(0,R.jsx)(y,{variant:`caption`,color:`text.secondary`,sx:{display:`block`},children:a}),r.author&&(0,R.jsxs)(y,{variant:`body2`,color:`text.secondary`,noWrap:!0,children:[r.author,r.artist&&r.artist!==r.author?` · ${r.artist}`:``]}),r.genre&&r.genre.length>0&&(0,R.jsx)(y,{variant:`body2`,color:`text.secondary`,noWrap:!0,children:r.genre.join(`, `)})]})]})},r.id)})})]})]})}export{B as AdvancedLibrarySearch};